from django.apps import AppConfig


class CharityConfig(AppConfig):
    name = 'charity'
