import django
import os
import logging
import random
from datetime import date
from dateutil.parser import parse

from cutecharts.charts import Pie
from time import localtime
from django.http import HttpResponse, FileResponse
from django.shortcuts import render, redirect

# from .map import map_visual
from .models import *

if not os.path.exists("./log"):
    os.mkdir("./log")

t = localtime()
logging.basicConfig(level=logging.DEBUG,format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',\
                        datefmt='%a, %d %b %Y %H:%M:%S', filename="log/%d_%d_%d.log"%(t[0],t[1],t[2]), filemode='a')    # initialize the logging format

# Create your views here.
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "charity.settings")
django.setup()

project_id = ""

con_d = {
    "user_id": None,
    "user_name": "",
    "user_type": "",
    "user_password": ""
}

dic_b = {
    "user_id": None,
    "user_name": "",
    "user_type": "",
    "user_password": ""
}

user_log = {"vin": 0}


def index(request):
    """
        Func:
            to force people to login.
    """
    dic = con_d.copy()
    all_pro = Project.objects
    total = len(all_pro.all())
    s_1 = len(all_pro.filter(status="1"))
    s_2 = len(all_pro.filter(status="2"))
    s_3 = len(all_pro.filter(status="3"))
    ratio = [s_1/total, s_2/total, s_3/total]

    cute_pie(["募款中", "执行中", "已结束"], ratio).render("./templates/default/visualize.html")
    # map_visual(Project, "./templates/default/map.html")
    if con_d["user_name"] == "":
        return redirect("/home/login")
    else:
        return HttpResponse(render(request, "../templates/default/home.html", context=dic))


def info(request):
    """
        Func:
            To show users the project information and provide an entrance to donate.
    """
    if con_d["user_name"] == "":
        return redirect("/home/login")
    global project_id
    pid = request.GET.get("id", "")

    # to fix the bug if we refresh the webpage - it won't resend a request containing project-id
    if pid == "" and request.method == "GET":
        tem_data = Fund.objects.get(project_id=con_d["project_id"])
        con_d["cum_amount"] = tem_data.cum_amount
        con_d["percentage"] = tem_data.cum_amount / tem_data.target_amount * 100
        con_d["donor_num"] = tem_data.donor_num
        if con_d["user_type"] == "Donor":
            return render(request, "../templates/default/infor.html", context=con_d)
        else:
            return render(request, "../templates/default/info_admin.html", context=con_d)
    else:
        project_id = pid

    if request.method == "GET":
        tem_data = Project.objects.get(project_id=project_id)
        con_d["project_name"] = tem_data.project_name
        con_d["project_id"] = project_id
        con_d["status"] = statusTrans(tem_data.status)
        con_d["start_date"] = tem_data.start_date
        con_d["end_date"] = tem_data.end_date
        con_d["category"] = tem_data.category
        con_d["province"] = tem_data.project_province
        con_d["introduction"] = tem_data.introduction
        tem_data = Fund.objects.get(project_id=project_id)
        con_d["target_amount"] = tem_data.target_amount
        con_d["cum_amount"] = tem_data.cum_amount
        con_d["percentage"] = tem_data.cum_amount/tem_data.target_amount*100
        con_d["donor_num"] = tem_data.donor_num
        return render(request, "../templates/default/infor.html", context=con_d)
    else:
        # to donate
        amount = request.POST.get('amount', '')
        pid = request.POST.get('id', '')
        print(pid)
        print(amount)
        donor = Donor.objects.get(donor_id=con_d["user_id"])
        donate = Donate(donor=donor, amount=amount, project_id=pid)
        donate.save()
        old_fund = Fund.objects.get(project_id=pid)
        fund = Fund(project_id=pid, donor_num=old_fund.donor_num+1, \
                    cum_amount=old_fund.cum_amount+int(amount), target_amount=old_fund.target_amount)
        fund.save()
    return render(request, "../templates/default/infor.html", context=con_d)


def edit(request):
    """
        Func:
            Allow admin to add a new project.
    """
    # to check if the user has logout
    if con_d["user_name"] == "":
        return redirect("/home/login")
    if request.method == "POST":
        pro_id = request.POST.get('id', '')
        pro_name = request.POST.get('name', '')
        start = request.POST.get('start', '')
        end = request.POST.get('end', '')
        price = request.POST.get('price', '')
        intro = request.POST.get('introduction', '')
        status = request.POST.get('status', '')
        # amount = request.POST.get('amount', '')

        # to update our database to add the new project
        start_d = parse(start)
        end_d = parse(end)
        project = Project(
            project_name=pro_name,
            project_id=pro_id,
            duration="%s 至 %s"%(start, end),
            start_date=date(start_d.year, start_d.month, start_d.day).strftime('%Y-%m-%d'),
            end_date=date(end_d.year, end_d.month, end_d.day).strftime('%Y-%m-%d'),
            introduction=intro,
            project_province="",
            category="",
            status=status
        )
        project.save()

        fund = Fund(
            fund_id=pro_name,
            project_id=pro_id,
            donor_num=0,
            cum_amount=0,
            target_amount=price,
        )
        fund.save()

    return HttpResponse(render(request, "../templates/default/add-edit.html", context=con_d))


def login(request):
    logout()
    if request.method == "GET":
        return HttpResponse(render(request, "../templates/default/login.html"))
    elif request.method == "POST":
        uid = request.POST.get('user-id', '')
        password = request.POST.get('password', '')
        utype = request.POST.get("utype", '')

        # defend attractors
        global user_log
        print(user_log)
        try:
            cnt = user_log[uid]
        except:
            user_log[uid] = 0
            cnt = user_log[uid]
        if cnt > 9:
            return HttpResponse(render(request, "../templates/default/404.html"))

        if utype == "0":
            utype = "Donor"
        else:
            utype = "Administrator"

        try:
            if utype == "Donor":
                d = Donor.objects.get(donor_id=uid)
            else:
                d = Admin.objects.get(admin_id=uid)

            if d:
                if d.password == password:
                    if utype == "Donor":
                        user_name = d.donor_name
                    else:
                        user_name = d.admin_name

                    global con_d
                    con_d["user_id"] = uid
                    con_d["user_name"] = user_name
                    con_d["user_type"] = utype
                    con_d["user_password"] = password
                    user_log.get(uid, 0)
                    user_log[uid] = 0
                    return redirect("/home", context=con_d)# render(request, "../templates/default/home.html", context=con_d)
                else:
                    user_log["123"] = 1
                    try:
                        user_log[uid] += 1
                    except:
                        user_log[uid] = 0
            else:
                user_log.get(uid, 0)
                user_log[uid] += 1

        except Exception as e:
            print(e)
            logging.error("\n%s\n"%e)
        return HttpResponse(render(request, "../templates/default/login.html"))


def my(request):
    """
        Func:
            The function for "My" page. To edit our personal information and check our donate records.
    """
    # to check if user has disconnected
    if con_d["user_name"] == "":
        return redirect("/home/login")

    # to edit user's name or password
    if request.method == "POST":
        uid = request.POST.get("id")

        if uid[1] == "D":
            typeOfUser = 0
        else:
            typeOfUser = 1

        try:
            name = request.POST.get("name")
            if name == "" or name == None:
                pwd = request.POST.get("password")
                if typeOfUser == 1:
                    name = Admin.objects.filter(admin_id=uid)[0].admin_name
                else:
                    name = Donor.objects.filter(donor_id=uid)[0].donor_name
            else:
                if typeOfUser == 1:
                    pwd = Admin.objects.filter(admin_id=uid)[0].password
                else:
                    pwd = Donor.objects.filter(donor_id=uid)[0].password
        except Exception as e:
            logging.error("\n%s\n"%e)
        print(name, uid, pwd)
        con_d["user_name"] = name
        con_d["user_password"] = pwd
        if typeOfUser == 0:
            user = Donor(donor_name=name, donor_id=uid, password=pwd)
        else:
            user = Admin(admin_name=name, admin_id=uid, password=pwd)
        user.save()
    if con_d["user_type"] == "Donor":
        return render(request, "../templates/default/my.html", context=con_d)
    else:
        return render(request, "../templates/default/my_admin.html", context=con_d)


def register(request):
    """
        Func:
            The function for "Register" page. To implement the sign up function.
    """
    if request.method == "POST":
        user_name = request.POST.get('user-name', '')
        password = request.POST.get('password', '')
        utype = request.POST.get("utype", '')

        # automatically give new user an id, and update our database
        if utype == "0":
            id = "UD0"
            ids = [d["donor_id"] for d in Donor.objects.all().values("donor_id")]
            # to ensure the new id is unique
            while id in ids:
                id = "UD%s"%(random.randint(0, 99999999999999999))

            donor = Donor.objects.create(donor_name=user_name, donor_id=id, password=password)
            donor.save()
            utype = "Donor"
        elif utype == "1":
            id = "UA0"
            ids = [d["admin_id"] for d in Admin.objects.all().values("admin_id")]
            # to ensure the new id is unique
            while id in ids:
                id = "UA%s"%(random.randint(0, 99999999999999999))
            admin = Admin(admin_name=user_name, admin_id=id, password=password)
            admin.save()
            utype = "Administrator"
        global con_d
        con_d["user_id"] = id
        con_d["user_name"] = user_name
        con_d["user_type"] = utype
        con_d["user_password"] = password
        return redirect("/home")

    return HttpResponse(render(request, "../templates/default/register.html"))


def search(request):
    """
        Func:
            The function for "search" page. To implement the searching function.
    """
    if con_d["user_name"] == "":
        return redirect("/home/login")

    dic = con_d.copy()
    if request.method == "GET":
        data_pro = Project.objects.all()
        dic["pro_data"] = [(str(i.project_id).split("(")[-1].replace(")",""), i.project_name, i.category, statusTrans(i.status)) for i in data_pro]
        if dic["user_type"] == "Donor":
            return render(request, "../templates/default/search-donor.html", context=dic)
        else:
            return HttpResponse(render(request, "../templates/default/search.html", context=dic))
    else:
        query = request.POST.get("top-search")

        # if we search nothing, we show all projects we have
        if query == "":
            data_pro = Project.objects.all()
            dic["pro_data"] = [
                (str(i.project_id).split("(")[-1].replace(")", ""), i.project_name, \
                 i.category, statusTrans(i.status)) for i in data_pro
            ]
            if dic["user_type"] == "Donor":
                return render(request, "../templates/default/search-donor.html", context=dic)
            else:
                return HttpResponse(render(request, "../templates/default/search.html", context=dic))

        # to do the searching
        p1 = Project.objects.filter(project_name__icontains=query).values("project_id", "project_name", "category", "status")
        p2 = Project.objects.filter(category__icontains=query).values("project_id", "project_name", "category", "status")
        p3 = Project.objects.filter(status__icontains=query).values("project_id", "project_name", "category", "status")
        p4 = Project.objects.filter(project_name=query).values("project_id", "project_name", "category", "status")
        p5 = Project.objects.filter(category=query).values("project_id", "project_name", "category", "status")
        p6 = Project.objects.filter(status=query).values("project_id", "project_name", "category", "status")
        p = list(p1)+list(p2)+list(p3)+list(p4)+list(p5)+list(p6)
        if len(p) == 0:
            dic = {}
            length = 1
        else:
            length = len(p)
        log_id = []     # to log the project_id, so that we can eliminate the duplicated values
        dic["pro_data"] = []
        for i in range(1, length):
            if p[i]["project_id"] in log_id:
                continue
            dic["pro_data"].append(list(p[i].values()))
            dic["pro_data"][-1][-1] = statusTrans(dic["pro_data"][-1][-1])
            log_id.append(p[i]["project_id"])

        return HttpResponse(render(request, "../templates/default/search.html", context=dic))


def delete(request):
    """
        Func:
            allow the admin to delete the project
    """
    delete_id = request.POST.get("id", "")
    Donate.objects.filter(project=delete_id).delete()
    Initiate.objects.filter(project=delete_id).delete()
    Manage.objects.filter(project=delete_id).delete()
    Receive.objects.filter(project=delete_id).delete()
    Fund.objects.filter(project_id=delete_id).delete()
    Project.objects.filter(project_id=delete_id).delete()
    return HttpResponse(render(request, "../templates/default/search.html", context=con_d))


def cute_pie(xticks, y, inner_radius=None, title=""):
    """
        Func:
            to product a webpage contains a cute pie chart.
        Args:
            xticks: our x values
            y: our y values
            inner_radius:
            title: the title of our graph, default to be nothing
        Return:
            the webpage script we already render.
    """
    chart = Pie(title)
    if inner_radius==None:
        chart.set_options(
            labels=xticks,
        )
    else:
        chart.set_options(
            labels=xticks,
            inner_radius=0,
        )
    chart.add_series(y)
    return chart


def iframe1(request):
    """
        Func:
            to return a webpage we wanna put in an iframe element.
    """
    return render(request, '../templates/default/visualize.html')


def logout():
    """
        Func:
            ensure to clean the login data
    """
    global con_d
    con_d = {
        "user_id": None,
        "user_name": "",
        "user_type": "",
        "user_password": ""
    }


def statusTrans(status):
    """
        Func:
            to transform the status from number to words.

        Returns:
            transformed status.
    """
    if status == "1":
        return "募款中"
    elif status == "2":
        return "执行中"
    else:
        return "已结束"


def download_map(request):
    """
        Func:
            to download the map visualization.

        Returns:
            to return the map visualization html file.
    """
    file = open('static/images/map.html', 'rb')
    response = FileResponse(file)
    response['Content-Type'] = 'application/octet-stream'
    response['Content-Disposition'] = 'attachment;filename="map.html"'
    return response
