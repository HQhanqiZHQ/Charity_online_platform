from django import forms
from django.core.exceptions import ValidationError
import charity.models


class LoginForm(forms.Form):
    name = forms.CharField(max_length=10)  # Field name made lowercase.
    id = forms.CharField(max_length=30)  # Field name made lowercase.
    password = forms.CharField(max_length=20, error_messages={"required": "Please enter your password!"})  # Field name made lowercase.


class DonateForm(forms.Form):
    """
        Func:

    """
    donor_id = forms.CharField(max_length=20)  # Field name made lowercase.
    amount = forms.DecimalField(max_digits=10, decimal_places=2)  # Field name made lowercase.
    project = forms.CharField(max_length=30)  # Field name made lowercase.


class FundForm(forms.Form):
    fund_id = forms.CharField(max_length=20)  # Field name made lowercase.
    project = forms.CharField(max_length=30)  # Field name made lowercase.
    donor_num = forms.IntegerField()  # Field name made lowercase.
    cum_amount = forms.DecimalField(max_digits=10, decimal_places=2)  # Field name made lowercase.
    target_amount = forms.DecimalField(max_digits=10, decimal_places=2)  # Field name made lowercase.


class InitiateForm(forms.Form):
    ini_name = forms.CharField(max_length=20)  # Field name made lowercase.
    project = forms.CharField(max_length=30)  # Field name made lowercase.


class InitiatorForm(forms.Form):
    ini_name = forms.CharField(max_length=30)  # Field name made lowercase.
    ini_contact = forms.CharField(max_length=20)  # Field name made lowercase.


class ManageForm(forms.Form):
    admin_id = forms.CharField(max_length=20)  # Field name made lowercase.
    project = forms.CharField(max_length=30)  # Field name made lowercase.


class PossessForm(forms.Form):
    project_id = forms.CharField(max_length=40)  # Field name made lowercase.
    fund_id = forms.CharField(max_length=20)  # Field name made lowercase.


class ProjectForm(forms.Form):
    project_name = forms.CharField(max_length=20)  # Field name made lowercase.
    project = forms.CharField(max_length=30)  # Field name made lowercase.
    duration = forms.CharField(max_length=30)  # Field name made lowercase.
    start_date = forms.DateField()  # Field name made lowercase.
    end_date = forms.DateField()  # Field name made lowercase.
    introduction = forms.CharField(max_length=40)  # Field name made lowercase.
    project_province = forms.CharField(max_length=10)  # Field name made lowercase.
    category = forms.CharField(max_length=10)  # Field name made lowercase.
    status = forms.CharField(max_length=10)  # Field name made lowercase.


class ReceiveForm(forms.Form):
    reci_name = forms.CharField()  # Field name made lowercase.
    project = forms.CharField(max_length=30)  # Field name made lowercase.


class RecipientForm(forms.Form):
    reci_name = forms.CharField(max_length=30)  # Field name made lowercase.
    reci_contact = forms.CharField(max_length=20)  # Field name made lowercase.

