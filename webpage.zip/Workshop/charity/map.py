from pyecharts import Geo #pyecharts 0.5.11 + snapshot
import pandas as pd

def map_visual(Object, path="./map.html"):
    #info = pd.read_excel(r'Project.xlsx') #read from object
    info = Object.objects.all().values_list("project_province")
    print(info)
    total = [i[0] for i in info] #selecr province column

    dic = {"山东":0,"辽宁":0,"天津":0,"宁夏":0,"湖北":0,
            "陕西":0,"安徽":0,"广东":0,"西藏":0,"内蒙古":0,
            "北京":0,"贵州":0,"湖南":0,"云南":0,"新疆":0,
            "河南":0,"江西":0,"上海":0,"福建":0,"四川":0,
            "重庆":0,"甘肃":0,"广西":0,"海南":0,"黑龙江":0,
            "河北":0,"吉林":0,"青海":0,"山西":0,"浙江":0,
            "江苏":0}


    for i in range(len(total)):
        if total[i][-2:] == '地区' or total[i] == "爱无国界(非中国)" or total[i] == "全国范围":
                continue
        elif total[i][-3:]  == '自治区':
            if total[i][0] == "内":
                dic[total[i][:3]] += 1
            else:
                dic[total[i][:2]] += 1
        elif total[i][-1] == "市" or total[i][-1] == "省":
            dic[total[i][:-1]] += 1
        else:
            continue

    data = [(a, dic[a]) for a in dic]

    geo=Geo("Charity Projects in China","Produced by UIC CHARITY",title_color="#fff",title_pos="center",width=1200,height=800,background_color='#404a59')
    attr,value=geo.cast(data)
    geo.add("",attr,value,visual_range=[0,max(dic.values())],visual_text_color="#fff",symbol_size=17,is_visualmap=True)
    geo.show_config()
    geo.render(path)
