var regex = /.*csrftoken=([^;.]*).*$/ ;
var xCSRFToken = document.cookie.match(regex) === null ? null : document.cookie.match(regex)[1];
$(document).ready(!function(t){"use strict";function o(){}o.prototype.init=function(){t("#inline-editable").Tabledit({
	url: "http://127.0.0.1:8000/home/my/",
	inputClass:"form-control form-control-sm",
	editButton:!1,
	deleteButton:!1,
	columns:{identifier:[0,"id"],editable:[[1,"name"],[2,"password"],[3,"col3"],[4,"col4"],[6,"col6"]]},
	})},t.EditableTable=new o,t.EditableTable.Constructor=o}(window.jQuery),function(){"use strict";window.jQuery.EditableTable.init()}());
$.ajaxSetup({
		headers: {
			"X-CSRFToken":xCSRFToken
		},
	});
;